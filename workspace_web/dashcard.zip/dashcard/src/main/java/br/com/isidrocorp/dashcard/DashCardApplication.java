package br.com.isidrocorp.dashcard;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DashCardApplication {

	public static void main(String[] args) {
		SpringApplication.run(DashCardApplication.class, args);
	}

}
